// Gaven Leef | sept 15 2026 | Calculator
Button[] numButtons = new Button[10];
Button[] opButtons = new Button[10];
float l, r, result;
char op;
boolean left, newEntry;
String displayVal, currentInput;

void setup() {
  size(130, 200);
  l = 0.0;
  r = 0.0;
  result = 0.0;
  op = ' ';
  left = true;
  newEntry = true;
  displayVal = "0.0";

  numButtons[0] = new Button(50, 170, 20, 20, '0');
  numButtons[1] = new Button(20, 140, 20, 20, '1');
  numButtons[2] = new Button(50, 140, 20, 20, '2');
  numButtons[3] = new Button(80, 140, 20, 20, '3');
  numButtons[4] = new Button(20, 110, 20, 20, '4');
  numButtons[5] = new Button(50, 110, 20, 20, '5');
  numButtons[6] = new Button(80, 110, 20, 20, '6');
  numButtons[7] = new Button(20, 80, 20, 20, '7');
  numButtons[8] = new Button(50, 80, 20, 20, '8');
  numButtons[9] = new Button(80, 80, 20, 20, '9');

  opButtons[0] = new Button(110, 140, 20, 20, '+');
  opButtons[1] = new Button(110, 110, 20, 20, '-');
  opButtons[2] = new Button(110, 80, 20, 20, '÷');
  opButtons[3] = new Button(110, 50, 20, 20, '×');
  opButtons[4] = new Button(20, 170, 20, 20, '.');
  opButtons[5] = new Button(110, 170, 20, 20, '=');
  opButtons[6] = new Button(80, 170, 20, 20, '±');
  opButtons[7] = new Button(20, 50, 20, 20, 'C');
  opButtons[8] = new Button(50, 50, 20, 20, '√');
  opButtons[9] = new Button(80, 50, 20, 20, 's');
}

void draw() {
  background(33);
  drawDisplay();
  for (int i = 0; i<numButtons.length; i++) {
    numButtons[i].display();
    numButtons[i].mouseOver(mouseX, mouseY);
  }
  for (int i = 0; i<opButtons.length; i++) {
    opButtons[i].display();
    opButtons[i].mouseOver(mouseX, mouseY);
  }
}

void drawDisplay() {
  rectMode(CENTER);
  fill(127);
  rect(width/2, 20, 110, 30);
  fill(0);
  textAlign(RIGHT);
  text(displayVal, width-15, 25);
  if(displayVal.length()>12){
    textSize(32);
  } else if (displayVal.length()>14) {
    textSize(30);
  }
}

void mouseReleased() {


  //display vairables
  //Number buttons
  for (int i = 0; i < numButtons.length; i++) {
    if (numButtons[i].hover) {
      handleEvent(numButtons[i].val, true);
    }
  }

  //operator buttons

  for (int i = 0; i < opButtons.length; i++) {
    if (opButtons[i].hover == true) {
      handleEvent(opButtons[i].val, false);
    }
  }



  // display variables
  println("L:" + l);
  println("R:" + r);
  println("Result:" + result);
  println("Left:" + left);
  println("Op:" + op);
}



void performCalc() {
  if (op == '+') {
    result = l + r;
  } else if (op == '-') {
    result = l - r;
  } else if (op == '÷') {
    result = l / r;
  } else if (op == '×') {
    result = l * r;
  }

  displayVal = str(result);
  left = !left;
  r=0.0;
}

void keyPressed() {
  println("keyCode: " + keyCode);
  if (keyCode == 49 || keyCode == 97) {
    handleEvent('1', true);
  } else if (keyCode == 50 || keyCode == 98) {
    handleEvent('2', true);
  } else if (keyCode == 51 || keyCode == 99) {
    handleEvent('3', true);
  } else if (keyCode == 52 || keyCode == 100) {
    handleEvent('4', true);
  } else if (keyCode == 53 || keyCode == 101) {
    handleEvent('5', true);
  } else if (keyCode == 54 || keyCode == 102) {
    handleEvent('6', true);
  } else if (keyCode == 55 || keyCode == 103) {
    handleEvent('7', true);
  } else if (keyCode == 56 || keyCode == 104) {
    handleEvent('8', true);
  } else if (keyCode == 57 || keyCode == 105) {
    handleEvent('9', true);
  } else if (keyCode == 58 || keyCode == 106) {
    handleEvent('0', true);
  } else if (keyCode == 47 || keyCode == 111) {
    handleEvent('÷', false);
  } else if ( keyCode == 106) {
    handleEvent('×', false);
  } else if (keyCode == 45 || keyCode == 109) {
    handleEvent('-', false);
  } else if ( keyCode == 107) {
    handleEvent('+', false);
  } else if ( keyCode == 10) {
    handleEvent('=', false);
  }else if (keyCode == 46 || keyCode == 110) {
    handleEvent('.', false);
  }
}
void handleEvent(char val, boolean isNum) {
  if (isNum == true) {
    //do number stuff
    String digit = str(val);

    if (newEntry || displayVal.equals("0.0")) {
      displayVal = digit;
      newEntry = false;
    } else {
      displayVal += digit;
    }

    if (left) {
      l = float(displayVal);
    } else {
      r = float(displayVal);
    }
  } else {
    //do operator stuff
    char clicked = val;
    if (clicked== '=') {
      performCalc();
    } else if (clicked == '+' || clicked == '-' || clicked == '×' || clicked == '÷') {
      op = clicked;
      left = false;
      newEntry = true;
      displayVal = str(op);
    } else if (clicked == '.') {
        if (!displayVal.contains(".")) {
          displayVal += ".";
        }
    } else if (clicked == '±') {
      if (left == true) {
        l *= -1;
        displayVal = str(l);
      } else {
        r *= -1;
        displayVal = str(r);
      }
    } else if (clicked == 'C') {
      l = 0.0;
      r = 0.0;
      result = 0.0;
      op = ' ';
      displayVal = "0.0";
      left = true;
      newEntry = true;
    } else if (clicked == '√') {
      if (left == true) {
        l = sqrt(l);
        displayVal = str(l);
      } else {
        r = sqrt(r);
        displayVal = str(r);
      }
    } else if (clicked == 's') {
      if (left == true) {
        l = sin(radians(l));
        displayVal = str(l);
      } else {
        r = sin(radians(r));
        displayVal = str(r);
      }
    }
  }
}
