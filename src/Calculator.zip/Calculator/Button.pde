class Button {
  //Member variables
  float x, y, w, h;
  char val;
  boolean hover;
  color c1, c2;

  //constructor
  Button(float x, float y, float w, float h, char val) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.val = val;
    hover = false;
    c1 = color(#FA5017);
    c2 = color(0);
  }

  //Member Methods
  void display() {
    if (hover ==true) {
      fill(c2);
    } else {
      fill(c1);
    }
    rectMode(CENTER);
    rect(x, y, w, h, 3);
    fill(255);
    textAlign(CENTER);
    textSize(16);
    text(val, x, y+5);
  }

  void mouseOver(float tempX, float tempY) {
    if (tempX>x-w/2 && tempX<x+w/2 && tempY>y-h/2 && tempY<y+h/2) {
      hover = true;
    } else {
      hover = false;
    }
  }
}
